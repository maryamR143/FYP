-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2024 at 04:23 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updationDate`) VALUES
(1, 'MRadmin', 'cs21@12345', '28-12-2022 11:42:05 AM');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `cat_name` varchar(50) DEFAULT NULL,
  `cat_description` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `cat_name`, `cat_description`) VALUES
(1, 'decoration', 'dfsdfg'),
(2, 'kitchen', 'gfdgh');

-- --------------------------------------------------------

--
-- Table structure for table `conferart`
--

CREATE TABLE `conferart` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `Reviewer` varchar(255) DEFAULT NULL,
  `Venue` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `FacultyRemark` mediumtext DEFAULT NULL,
  `LastupdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `conferart`
--

INSERT INTO `conferart` (`id`, `fullname`, `Reviewer`, `Venue`, `PostingDate`, `FacultyRemark`, `LastupdationDate`) VALUES
(1, 'CS paper 21', 'IBAS', 'Karachi', '2022-06-29 19:03:08', 'Test Admin Remark', '2022-11-25 03:01:37'),
(2, 'CS Paper 22', 'Ibas', 'Islamabad', '2019-06-30 13:06:50', 'Answered', '2022-11-25 03:00:31'),
(3, 'CS Paper 19', 'Ibas', 'Lahore', '2019-11-10 18:53:48', 'In process', '2022-11-25 03:00:31'),
(4, 'CS Paper 2018', 'IBAS', 'Multan', '2020-07-05 01:57:20', 'answered', '2022-11-25 03:00:31');

-- --------------------------------------------------------

--
-- Table structure for table `journalartical`
--

CREATE TABLE `journalartical` (
  `ID` int(10) NOT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `DateIssue` datetime(6) DEFAULT NULL,
  `Chapter` bigint(10) DEFAULT NULL,
  `Volume/Edition` int(200) DEFAULT NULL,
  `no_of_Issues` varchar(50) DEFAULT NULL,
  `City` mediumtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `journalartical`
--

INSERT INTO `journalartical` (`ID`, `Name`, `DateIssue`, `Chapter`, `Volume/Edition`, `no_of_Issues`, `City`) VALUES
(1, 'Nameera', '2022-08-12 00:00:00.000000', 18, 2, 'TWO', 'New York'),
(4, 'Filzah', '2022-07-19 00:00:00.000000', 4, 20, 'three', 'Karachi'),
(5, 'Maryam', '2022-03-14 00:00:00.000000', 24, 4, 'five', 'multan'),
(6, 'anus', '2022-07-16 00:00:00.000000', 28, 6, '17', 'islamabad'),
(7, 'fillu', '2022-07-15 00:00:00.000000', 29, 17, '8', 'faislabad\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `pro_name` varchar(50) DEFAULT NULL,
  `pro_description` varchar(5000) DEFAULT NULL,
  `pro_cat` int(11) DEFAULT NULL,
  `pro_availability` varchar(50) DEFAULT NULL,
  `pro_qty` int(11) DEFAULT NULL,
  `pro_price` int(11) DEFAULT NULL,
  `pro_image` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `pro_name`, `pro_description`, `pro_cat`, `pro_availability`, `pro_qty`, `pro_price`, `pro_image`) VALUES
(1, 'Product 1', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. In illum, voluptates ex culpa molestiae nihil!', 1, 'Available', 5, 1300, 'img1.jpg,'),
(2, 'Product 2', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. In illum, voluptates ex culpa molestiae nihil!', 1, 'Available', 10, 1650, 'img2.jpg'),
(3, 'Product 3', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. In illum, voluptates ex culpa molestiae nihil!', 1, 'Available', 10, 1430, 'img3.jpg'),
(9, 'dvfsd', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. In illum, voluptates ex culpa molestiae nihil!', 1, 'yes', 34, 65, '4.jpg,5.jpg,6.jpg'),
(11, 'Sport Shoes', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. In illum, voluptates ex culpa molestiae nihil!', 2, 'yes', 200, 3400, 'fila.jpg,im.jpg,tetr.png,ty.jfif'),
(12, 'tr', 'nhsdakukBYCIUYUICl', 1, 'available', 2, 1500, 'download.png');

-- --------------------------------------------------------

--
-- Table structure for table `researcharticle`
--

CREATE TABLE `researcharticle` (
  `id` int(11) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Jid` int(11) DEFAULT NULL,
  `Cid` int(11) DEFAULT NULL,
  `Author` varchar(20) DEFAULT NULL,
  `PublicationDate` varchar(255) DEFAULT NULL,
  `Topic` varchar(255) DEFAULT NULL,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `researcharticle`
--

INSERT INTO `researcharticle` (`id`, `Title`, `Jid`, `Cid`, `Author`, `PublicationDate`, `Topic`, `updationDate`) VALUES
(3, 'Artificial Intelligence', 7, 6, 'Aneesa', '2019-06-29', 'Design Algo', '2022-11-25 02:34:51'),
(4, 'Internet of Things', 5, 5, 'Maryam', '2019-11-08', 'Social Tech', '2022-11-25 02:34:51'),
(5, 'Computer Security', 9, 7, 'Fawad', '2019-11-30', 'Systaltic Research', '2022-11-25 02:34:51'),
(6, 'Computer Architecture', 11, 2, 'Nazim', '2020-07-14', 'Global IT', NULL),
(7, 'Machine Learning', 3, 2, 'Farah MD', '2020-07-05', 'Science', NULL),
(8, 'Robotics', 0, 2, 'Filzah', '2022-07-13', 'IT', NULL),
(9, 'Census Technology', 0, 2, 'Nameera', '2022-07-13', 'CS', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(24, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 01:50:24', NULL, 1),
(25, NULL, 'serbermz2020@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:09:18', NULL, 0),
(26, NULL, 'serbermz2020@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:11:05', NULL, 0),
(27, NULL, 'test@demo.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:11:24', NULL, 0),
(28, NULL, 'serbermz2020@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:11:46', NULL, 0),
(29, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2020-07-05 02:12:00', NULL, 1),
(30, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2022-07-06 19:06:59', NULL, 1),
(31, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2022-07-07 16:05:11', '08-07-2022 02:02:46 AM', 1),
(32, 8, 'maryamraza@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-09 15:52:56', '09-11-2022 09:24:15 PM', 1),
(33, 8, 'maryamraza@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-24 14:07:28', NULL, 1),
(34, NULL, 'maryam@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-24 14:20:19', NULL, 0),
(35, 8, 'maryamraza@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-24 14:20:35', '24-11-2022 07:50:39 PM', 1),
(36, 8, 'maryamraza@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-24 20:01:15', NULL, 1),
(37, NULL, 'maryamtalha@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-24 21:06:03', NULL, 0),
(38, 11, 'maryamtalha@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-24 21:06:24', '25-11-2022 02:36:37 AM', 1),
(39, 8, 'maryamraza@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-24 21:35:37', '25-11-2022 03:05:55 AM', 1),
(40, 8, 'maryamraza@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-25 04:35:39', '25-11-2022 10:06:54 AM', 1),
(41, 12, 'nameera@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-25 04:37:12', NULL, 1),
(42, 8, 'maryamraza@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-25 05:22:00', '25-11-2022 10:52:18 AM', 1),
(43, 12, 'nameera@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-25 05:44:59', '25-11-2022 11:15:30 AM', 1),
(44, 8, 'maryamraza@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-25 06:47:19', '25-11-2022 12:19:43 PM', 1),
(45, NULL, 'MRadmin', 0x3a3a3100000000000000000000000000, '2023-01-03 06:37:16', NULL, 0),
(46, NULL, 'MaryamR', 0x3a3a3100000000000000000000000000, '2023-01-03 06:39:55', NULL, 0),
(47, NULL, 'MaryamR', 0x3a3a3100000000000000000000000000, '2023-01-03 06:40:11', NULL, 0),
(48, NULL, 'Maryam', 0x3a3a3100000000000000000000000000, '2023-01-03 06:41:07', NULL, 0),
(49, NULL, 'Maryam', 0x3a3a3100000000000000000000000000, '2023-01-03 06:41:45', NULL, 0),
(50, NULL, 'Maryam', 0x3a3a3100000000000000000000000000, '2023-01-03 06:42:59', NULL, 0),
(51, NULL, 'MRadmin', 0x3a3a3100000000000000000000000000, '2023-01-03 06:53:46', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `Designation` longtext DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `Designation`, `city`, `gender`, `email`, `password`, `regDate`, `updationDate`) VALUES
(2, 'amna', 'karachi', 'karachi', 'female', 'test@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2022-11-09 15:52:26', '2022-11-24 18:05:35'),
(8, 'Maryam', 'waterpump', 'karachi', 'female', 'maryamraza@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2022-11-09 15:52:26', NULL),
(9, 'maryamtalha', '', 'karachi', 'female', 'maryamtalha@gmail', 'e10adc3949ba59abbe56e057f20f883e', '2022-11-24 21:04:21', NULL),
(10, 'maryamtalha', '', 'karachi', 'female', 'maryamtalha@gmail', 'e10adc3949ba59abbe56e057f20f883e', '2022-11-24 21:04:31', NULL),
(11, 'Maryam talha', 'MD', 'Karachi', 'female', 'maryamtalha@gmail.com', '2904f22c848940ad6167e7c1e5802b84', '2022-11-24 21:05:37', NULL),
(12, 'Nameera Sid', 'MD', 'Karachi', 'female', 'nameera@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2022-11-25 04:36:47', NULL),
(13, 'MaryamR', 'Proff', 'Karachi', 'female', 'maryamraza738@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2023-01-03 06:39:00', NULL),
(14, 'Maryam', 'proff', 'karachi', 'female', 'maryam@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2023-01-03 06:40:42', '2023-01-03 06:41:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conferart`
--
ALTER TABLE `conferart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `journalartical`
--
ALTER TABLE `journalartical`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pro_cat` (`pro_cat`);

--
-- Indexes for table `researcharticle`
--
ALTER TABLE `researcharticle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `conferart`
--
ALTER TABLE `conferart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `journalartical`
--
ALTER TABLE `journalartical`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `researcharticle`
--
ALTER TABLE `researcharticle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
