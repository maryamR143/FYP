# FYP
final year project: mindflex rehabilitation 
The project scope of MindFlex Rehabilitation encompasses the development of a groundbreaking platform that brings mental and physiotherapy rehabilitation directly into individuals' homes through Virtual Reality (VR). This comprehensive platform integrates various key features, including an AI chat feature designed to act as a virtual friend, offering initial solutions for mental and physical health inquiries. The application and web interface are equipped with personalized dashboards, enabling users to track their progress seamlessly. MindFlex revolutionize rehabilitation by combining advanced technology, personalized tracking mechanisms, and professional support, ultimately making mental and physiotherapy services more accessible, engaging, and effective for individuals seeking rehabilitation from the comfort of their homes.


